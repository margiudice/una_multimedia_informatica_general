function seleccionarImagen(ruta) {
  const contenedor = document.getElementById("contenedor_imagen_grande");
  const imagenGrande = document.getElementById("imagen_grande");
  imagenGrande.src = ruta;
  contenedor.style.display = "flex";
}

function mostrarOcultarContenedor() {
  const contenedor = document.getElementById("contenedor_imagen_grande");
  contenedor.style.display = "none";
}

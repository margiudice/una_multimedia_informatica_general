# Objetivos Mínimos:

- Armar el layout de las páginas del sitio en un software de imagen vectorial.

- Poder estructurar adecuadamente el sitio con etiquetas DIVs y HTML5.
  
- ~~Comprender adecuadamente la utilización de los estilos CSS.~~
  
- El sitio debe verse idéntico en los navegadores Chrome y Firefox.
  
- Resolver el diseño de los menús de navegación utilizando estilos CSS.
  
- Poder incorporar webfonts locales al sitio.
  
- **Realizar una galería de imágenes usando javascript**

----------
----------

- ~~Crear una carpeta para el sitio llamada apellido_apellido_apellido_tp3.~~
  
- ~~Dentro de esa carpeta deberán estar los archivos y las carpetas del sitio, carpeta img para las imágenes y los archivos html (index.html, galeria.html,contacto.html)~~

- Armar los layouts de cada página con algún software vectorial en formato svg. 
  
- Colocar todas las medidas de cada elemento de cada página del sitio. 
  
- Exportar los layouts con las medidas de cada página a formato png o jpg (index.png, galeria.png, contacto.png). 
  
- Guardarlos archivos en una carpeta llamada layout dentro de la carpeta del sitio.

- Armar el sitio para que se vea bien en una resolución estándar full hd (1920x1080) y/o que sea responsive y se adapte a cualquier tamaño.
  
- Desarrollar el sitio de forma tal que se vea de la misma manera en los navegadores Chrome y Firefox.

- ~~Las estructuras de las páginas se realizarán en HTML y todo lo que es diseño con estilos CSS.~~
  
- ~~Las páginas deberán estar vinculadas a una hoja de estilos llamada estilos.css alojada en la raíz del sitio.~~
  
- Crear un archivo funciones.js donde estará todo el código de JavaScript, haciendo el respectivo vínculo con los archivos .html

- <HEADER>
- ~~<MAIN>~~
- ~~<SECTION>~~
- <ARTICLE>
- <ASIDE>
- ~~<NAV>~~
- ~~<FOOTER>~~ 
  
- Utilizar semántica HTML5 para todo lo que es contenido. Utilizar las etiquetas h1, h2, h3, b, i, span, etc. para las jerarquías de títulos.
  
- Usar webfonts locales para las familias tipográficas.
  
- Los menús de navegación tienen que estar diseñados con estilos CSS.
  
- Todos los links externos deben abrir en una ventana o pestaña nueva del navegador. Por el contrario, los links internos deben abrirse en la misma ventana.
  
- Todas las imágenes tienen que tener el tamaño y la resolución apropiada, no se deben redimensionar en HTML ni en CSS.
  
-  No debe haber estilos ni código javascript en NINGÚN archivo HTML.


